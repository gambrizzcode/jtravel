-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 21, 2016 at 04:49 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `jtravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `mobil`
--

CREATE TABLE IF NOT EXISTS `mobil` (
  `id_mobil` varchar(100) NOT NULL,
  `merk` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `biayaperkm` int(100) NOT NULL,
  `penumpangmax` int(100) NOT NULL,
  `bagasimax` int(100) NOT NULL,
  `gambar` text NOT NULL,
  `status` int(1) NOT NULL,
  `ket` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mobil`
--

INSERT INTO `mobil` (`id_mobil`, `merk`, `type`, `nama`, `biayaperkm`, `penumpangmax`, `bagasimax`, `gambar`, `status`, `ket`) VALUES
('CAR-001', 'Hyundai', 'atz-001', 'Atoz', 7500, 5, 10, 'atoz.png', 0, ''),
('CAR-0010', 'Daihatsu', 'DH889R03', 'Rush', 15000, 10, 10, 'rush.png', 1, ''),
('CAR-0011', 'Lamborghini', 'LG-677.01Gal_57', 'Gallardo', 50000, 3, 5, 'gallardo.png', 0, ''),
('CAR-002', 'Toyota', 'T87A01', 'Alphard', 15000, 10, 5, 'Alphard.png', 1, ''),
('CAR-003', 'Honda', 'H555B1', 'Brio', 7500, 5, 10, 'brio.png', 0, ''),
('CAR-004', 'Toyota', 'T889F01', 'Fortuner', 15000, 7, 10, 'fortuner.png', 0, ''),
('CAR-005', 'Toyota', 'T887KI01', 'Inova', 15000, 7, 10, 'inova.png', 0, ''),
('CAR-006', 'Honda', 'H665JZ2', 'Jazz', 10000, 5, 10, 'jazz.png', 0, ''),
('CAR-007', 'Taft', 'T995J05', 'Jeep', 20000, 5, 20, 'jeep.png', 0, ''),
('CAR-008', 'Mitsubishi', 'M776PJ05', 'Pajero Sport', 20000, 10, 5, 'pajero.png', 1, ''),
('CAR-009', 'Porsche', 'P987CY4', 'Cayman', 20000, 5, 5, 'porsche.png', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `paket`
--

CREATE TABLE IF NOT EXISTS `paket` (
  `id_paket` int(100) NOT NULL,
  `id_wisata` varchar(100) NOT NULL,
  `id_mobil` varchar(100) NOT NULL,
  `id_sopir` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paket`
--

INSERT INTO `paket` (`id_paket`, `id_wisata`, `id_mobil`, `id_sopir`) VALUES
(9, 'DES_WI-06', 'CAR-002', 'DRV-001');

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE IF NOT EXISTS `pelanggan` (
  `id_pelanggan` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `telp` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `ket` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `nama`, `password`, `alamat`, `telp`, `email`, `ket`) VALUES
('PLG-01', 'Syaikhu Rizal', 'c93ccd78b2076528346216b3b2f701e6', 'kencong', '1923864190', 'permanen29@gmail.com', ''),
('PLG-02', 'rizal', '6eea9b7ef19179a06954edd0f6c05ceb', 'alsdjfh', '109234813427', 'alksdhfalksh@gmail.com', 'TENGGANG'),
('PLG-03', 'shubhan', '25d55ad283aa400af464c76d713c07ad', 'kencong', '08123456897', 'shubhan11@gmail.com', '');

-- --------------------------------------------------------

--
-- Table structure for table `petugas`
--

CREATE TABLE IF NOT EXISTS `petugas` (
  `kode_ptg` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `foto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `petugas`
--

INSERT INTO `petugas` (`kode_ptg`, `username`, `nama`, `password`, `foto`) VALUES
('PTG-001', 'gambris', 'Syaikhu Rizal', 'c93ccd78b2076528346216b3b2f701e6', 'via.jpg'),
('PTG-002', 'S.Rizal', 'Syech Rizal', '25d55ad283aa400af464c76d713c07ad', 'me.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `sopir`
--

CREATE TABLE IF NOT EXISTS `sopir` (
  `id_sopir` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `usia` int(100) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `telp` varchar(100) NOT NULL,
  `status` int(1) NOT NULL,
  `ket` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sopir`
--

INSERT INTO `sopir` (`id_sopir`, `nama`, `usia`, `alamat`, `telp`, `status`, `ket`) VALUES
('DRV-001', 'Subhan Busyro', 42, 'wonorejo', '081000111222', 0, ''),
('DRV-002', 'Wahyu Romadhona', 98, 'sukoreno', '009008007006', 0, ''),
('DRV-003', 'Fahmi Cumi', 25, 'Cakru', '098765432123', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE IF NOT EXISTS `transaksi` (
  `id_transaksi` varchar(100) NOT NULL,
  `id_pelanggan` varchar(100) NOT NULL,
  `id_wisata` varchar(100) NOT NULL,
  `id_mobil` varchar(100) NOT NULL,
  `id_sopir` varchar(100) NOT NULL,
  `penumpang` int(100) NOT NULL,
  `barang` int(100) NOT NULL,
  `tanggal` date NOT NULL,
  `total` int(100) NOT NULL,
  `ket` text NOT NULL,
  `kode_ptg` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `id_pelanggan`, `id_wisata`, `id_mobil`, `id_sopir`, `penumpang`, `barang`, `tanggal`, `total`, `ket`, `kode_ptg`) VALUES
('JT_161116/113848-1', 'plg-01', 'DES_WI-017', 'CAR-007', 'DRV-001', 2, 2, '2016-11-16', 1105000, 'LUNAS', 'PTG-001'),
('JT_161117/073856-4', 'PLG-04', 'DES_WI-010', 'CAR-0010', 'DRV-001', 10, 0, '2016-11-17', 1010000, 'LUNAS', 'PTG-001'),
('JT_161117/074555-5', 'PLG-04', 'DES_WI-02', 'CAR-0011', 'DRV-001', 3, 0, '2016-11-17', 2600000, 'LUNAS', 'PTG-001'),
('JT_161117/115039-3', 'plg-02', 'DES_WI-010', 'CAR-0010', 'DRV-001', 10, 0, '2016-11-17', 110600, 'LUNAS', 'PTG-001'),
('JT_161117/115644-4', 'plg-02', 'DES_WI-010', 'CAR-0010', 'DRV-001', 10, 0, '2016-11-17', 1010000, 'LUNAS', 'PTG-001'),
('JT_161118/122108-6', 'PLG-01', 'DES_WI-015', 'CAR-008', 'DRV-003', 5, 0, '2016-11-18', 1320000, 'LUNAS', 'PTG-001'),
('JT_161120/041038-8', 'plg-02', 'DES_WI-03', 'CAR-0010', '', 10, 0, '2016-11-20', 490000, 'LUNAS', 'PTG-001'),
('JT_161120/041426-9', 'plg-01', 'DES_WI-01', 'CAR-002', '', 10, 0, '2016-11-20', 125000, 'LUNAS', 'PTG-001'),
('JT_161120/042052-10', 'plg-02', 'DES_WI-019', 'CAR-0010', 'DRV-003', 10, 7, '2016-11-20', 785000, 'TENGGANG', ''),
('JT_161120/073024-8', 'plg-01', 'DES_WI-03', 'CAR-009', '', 5, 0, '2016-11-20', 650000, 'LUNAS', 'PTG-001');

-- --------------------------------------------------------

--
-- Table structure for table `wisata`
--

CREATE TABLE IF NOT EXISTS `wisata` (
  `id_wisata` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `jenis` varchar(100) NOT NULL,
  `jarak` int(100) NOT NULL,
  `tiket` int(100) NOT NULL,
  `telp` varchar(100) NOT NULL,
  `gambar` varchar(100) NOT NULL,
  `status` int(1) NOT NULL,
  `ket` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wisata`
--

INSERT INTO `wisata` (`id_wisata`, `nama`, `alamat`, `jenis`, `jarak`, `tiket`, `telp`, `gambar`, `status`, `ket`) VALUES
('DES_WI-01', 'Pantai Paseban', 'Desa Paseban, Kencong', 'alami', 8, 5000, '081999888776', 'paseban.png', 1, ''),
('DES_WI-010', 'Pemandian Oleng Sibutong', 'Jember Utara', 'buatan', 60, 10000, '043203210213', 'oleng.png', 1, ''),
('DES_WI-011', 'Pantai Papuma', 'Ambulu, Jember', 'alami', 35, 0, '07890987890', 'papuma.png', 1, ''),
('DES_WI-012', 'Pemandian Patemon', 'Tanggul, Jember', 'buatan', 35, 5000, '01230321000', 'patemon.png', 1, ''),
('DES_WI-013', 'Pantai Payangan', 'Ambulu, Jember', 'alami', 45, 0, '085855855855', 'payangan.png', 1, ''),
('DES_WI-014', 'Pantai Puger', 'Puger, Jember', 'alami', 15, 0, '012301230321', 'puger.png', 1, ''),
('DES_WI-015', 'Kawasan Puncak Rembangan', 'Rembangan, Jember', 'alami', 60, 20000, '054303450454', 'puncak.png', 1, ''),
('DES_WI-016', 'Kolam Renang Rembangan', 'Rembangan, Jember', 'buatan', 60, 20000, '098765432129', 'rembangan.png', 1, ''),
('DES_WI-017', 'Air Terjun Tancak', 'Panti, Jember', 'alami', 50, 5000, '076540987612', 'tancak.png', 1, ''),
('DES_WI-018', 'Tiara Waterpark', 'Ambulu, Jember', 'alami', 35, 15000, '098765432198', 'tiara.png', 1, ''),
('DES_WI-019', 'Pantai Watu Ulo', 'Ambulu, Jember', 'alami', 45, 10000, '098765432190', 'watuulo.png', 1, ''),
('DES_WI-02', 'Alun - Alun Kota Jember', 'Jember Pusat', 'buatan', 50, 0, '-', 'alunalun.png', 1, ''),
('DES_WI-03', 'Air Terjun Antrokan', 'Tanggul, Jember', 'alami', 32, 10000, '080090070010', 'antrokan.png', 1, ''),
('DES_WI-04', 'Pantai Bandealit', 'Tempurejo, Jember', 'alami', 60, 15000, '087787767777', 'bandealit.png', 1, ''),
('DES_WI-05', 'Bedadung', 'Rambipuji, Jember', 'alami', 30, 10000, '089978867756', 'bedadung.png', 1, ''),
('DES_WI-06', 'Taman Botani', 'Sukorambi, Jember', 'alami', 61, 5000, '081230098089', 'botani.png', 1, ''),
('DES_WI-07', 'Pemandian Kebon Agung', 'Kaliwates', 'buatan', 35, 10000, '085555455655', 'kebonagung.png', 1, ''),
('DES_WI-08', 'Loko Lori', 'Rambipuji, Jember', 'buatan', 30, 0, '012309870654', 'lokolori.png', 1, ''),
('DES_WI-09', 'Niagara Waterboom', 'Ambulu, Jember', 'buatan', 40, 15000, '098707890879', 'niagara.png', 1, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mobil`
--
ALTER TABLE `mobil`
 ADD PRIMARY KEY (`id_mobil`);

--
-- Indexes for table `paket`
--
ALTER TABLE `paket`
 ADD PRIMARY KEY (`id_paket`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
 ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indexes for table `petugas`
--
ALTER TABLE `petugas`
 ADD PRIMARY KEY (`kode_ptg`);

--
-- Indexes for table `sopir`
--
ALTER TABLE `sopir`
 ADD PRIMARY KEY (`id_sopir`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
 ADD PRIMARY KEY (`id_transaksi`);

--
-- Indexes for table `wisata`
--
ALTER TABLE `wisata`
 ADD PRIMARY KEY (`id_wisata`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
